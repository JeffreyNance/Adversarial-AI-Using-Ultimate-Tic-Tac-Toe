from utttenv import UltimateTicTacToeEnv
import numpy as np

class AlphaBetaAgent:
    Count = 0

    def __init__(self, env: UltimateTicTacToeEnv, depth = 5):
        self.env = env
        self.depth = depth
        self.Name = f"AlphaBetaAgent{'' if AlphaBetaAgent.Count < 1 else AlphaBetaAgent.Count}"
        AlphaBetaAgent.Count += 1
        self.NumberPrunes: int = 0

        #Stop Checking at 500 Expanded Nodes
        self.NodeCount = 0
        self.MaxNodes = 500

    #Here is where you should implement your minimax search method. You are free to do this however you like, it the act function just needs to return the action that is to be taken. 
    def act(self, depth: int = 0, simulated_current_env = None, AlphaBeta: list[int] = None) -> tuple[tuple[int, int], tuple[int, int]] | int:
        '''
        Always Start Depth at 0\n
        Never Originally Input simulated_current_env or AlphaBeta\n
        Always Pass AlphaBeta in as a Copy
        '''

        #Initializations
        if not(depth):
            self.NodeCount = 0
            simulated_current_env = UltimateTicTacToeEnv()
            simulated_current_env.set_state(self.env.get_state())
            AlphaBeta = [-99999, 99999]

        #Get All Legal Actions at This Depth
        LegalActions = simulated_current_env.legal_actions()
        SetLegalActions = set(LegalActions)

        #Search For The Best Current Action Based on The Next Five Moves (Including This Move)
        DepthMinus: bool = depth == self.depth - 1
        CurrDepthPlus: int = depth + 1
        MinNode: int = depth % 2
        BestAction: tuple[tuple[int]] = LegalActions[0]
        ActionValue: int = 0
        InnerAlphaBeta: list[int] = [-99999, 99999]
        for action in SetLegalActions: #Force Randomness to Not Always Expand The Same Nodes
            #Simulate The Action
            simulated_env = UltimateTicTacToeEnv()
            simulated_env.set_state(simulated_current_env.get_state())
            _, _, done, _ = simulated_env.step(action)

            #Stop Searching at MaxNodes Nodes
            if self.NodeCount >= self.MaxNodes:
                break
            self.NodeCount += 1

            #Get The Value of This Action
            if DepthMinus or done:
                #Evaluate The Deepest Layer of Search
                ActionValue = self.evaluate(simulated_env)
            #Prune The Branch When Beta < Alpha
            elif AlphaBeta[0] <= AlphaBeta[1]:
                #Take The MiniMax of The Layer Below
                _, InnerAlphaBeta = self.act(CurrDepthPlus, simulated_env, AlphaBeta.copy())
                AlphaBeta[MinNode] = InnerAlphaBeta[1 - MinNode]
                ActionValue = AlphaBeta[MinNode]
            else:
                self.NumberPrunes += 1

            #Keep The Best Action
            #Only Required For The Current Action -> Max Node
            if ActionValue > AlphaBeta[0] or (np.random.random() < 0.3 and ActionValue == AlphaBeta[0]):
                BestAction = action

            #Determine The Value of This Action Pertaining to The Current Move
            #Alternates The Information Into Alpha & Beta
            if (MinNode and ActionValue < AlphaBeta[MinNode]) or (not(MinNode) and ActionValue > AlphaBeta[MinNode]):
                AlphaBeta[MinNode] = ActionValue #Track The Best/Worst Action Value (Alpha/Beta) For AlphaBeta

        #Return Best Action & The Associated Value
        return LegalActions[LegalActions.index(BestAction)], AlphaBeta

    #Use this function to evaluate functions. This can be used to evaluate terminal states as well as non-terminal states. It's a relatively simple heuristic, but should get the job done. 
    #Had to Differentiate The Current Simulated Player From The Actual Current Player (Also Fixed Turn Order Issue) -> Same Function, Just Inverted For The Opposite Player
    #I am Unsure if my Fix Was a Fix From my Own Earlier Change or From Your Original Function
    def evaluate(self, env: UltimateTicTacToeEnv) -> int:
        winner = env.game.evaluate_global_win()
        usvalue = self.env.game.current_player.value
        us = 1 if env.game.current_player.value == usvalue else -1
        score: int = winner * 100 * us if winner != 2 else 0

        for row in env.game.local_board_states:
            for state in row:
                if state.value == usvalue:
                    score += 10 if us == 1 else 50
                elif state.value == -usvalue:
                    score += -50 if us == 1 else -10

        return score