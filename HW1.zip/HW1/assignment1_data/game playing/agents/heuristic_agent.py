from utttenv import UltimateTicTacToeEnv
import numpy as np

class HeuristicAgent:
    Count = 0

    def __init__(self, env: UltimateTicTacToeEnv):
        self.env = env
        self.Name = f"HeuristicAgent{'' if HeuristicAgent.Count < 1 else HeuristicAgent.Count}"
        HeuristicAgent.Count += 1

    def act(self):
        us = self.env.game.current_player.value
        LegalActions = self.env.legal_actions()
        for action in LegalActions:
            simulated_env = UltimateTicTacToeEnv()
            simulated_env.set_state(self.env.get_state())
            _, _, done, info = simulated_env.step(action)
            if done:
                if info['winner'] == us:
                    return action, None
            else:
                next_player_board_state = self.env.game.local_board_states[
                    action[1][0]
                ][action[1][1]]
                if next_player_board_state.value != 0:
                    continue

                local_board_state = self.env.game.local_board_states[action[0][0]][
                    action[0][1]
                ]
                if local_board_state.value == us:
                    return action, None

        return LegalActions[np.random.randint(0, len(LegalActions))], None