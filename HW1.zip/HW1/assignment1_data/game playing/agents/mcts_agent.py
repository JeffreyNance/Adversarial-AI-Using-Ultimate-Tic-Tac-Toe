import numpy as np
from utttenv import UltimateTicTacToeEnv

class MCTSAgent:
    exploration_weight: float = 0.10
    Count = 0

    #Basic init function. I've given you a little bit of a start, but feel free to alter this as you see fit. 
    def __init__(self, env, iterations=500):
        self.env: "UltimateTicTacToeEnv" = env
        self.iterations = iterations
        self.Name = f"MCTSAgent{'' if MCTSAgent.Count < 1 else MCTSAgent.Count}"
        MCTSAgent.Count += 1

    #Traverse to a Non-Terminal Leaf Node With Maximum Q Value
    def GetBestLeafNode(self, Root: "MCTSNode") -> "MCTSNode":

        #Create a Search Queue & Storage For The Best Leaves
        Q: list[MCTSNode] = [Root]
        BestLeafNodes: list[MCTSNode] = [Root]
        LegalActions: bool = len(Root.env.legal_actions()) > len(Root.Children)
        if not(LegalActions):
            BestLeafNodes.remove(Root)

        #Stop Searching at MaxNodes Nodes
        if MCTSNode.NodeCount >= MCTSNode.MaxNodes:
            if LegalActions:
                BestLeafNodes.remove(Root)
            Q.pop()

        #Loop Through The Queue
        while Q:
            Node: MCTSNode = Q.pop()

            #Check For Valid Children to Traverse
            for Child in Node.Children:
                LegalActions: bool = len(Child.env.legal_actions()) > len(Child.Children)

                if LegalActions and (not(BestLeafNodes) or Child.QValue > BestLeafNodes[0].QValue):
                    Q.append(Child)
                    BestLeafNodes = [Child]
                elif LegalActions and (not(BestLeafNodes) or Child.QValue == BestLeafNodes[0].QValue):
                    Q.append(Child)
                    BestLeafNodes.append(Child)

        return BestLeafNodes[np.random.randint(0, len(BestLeafNodes))] if BestLeafNodes else None

    #Simulate a Random Path to The End
    def RandomGamePath(self, Start: "MCTSNode", reward: int, done: bool) -> int:

        #Simulate The Environment
        simulated_env: UltimateTicTacToeEnv = UltimateTicTacToeEnv()
        simulated_env.set_state(Start.env.get_state())

        #Loop Until The End, Keeping The Reward
        while not(done):
            #Take a Random Legal Action
            LegalActions = simulated_env.legal_actions()
            _, reward, done, _ = simulated_env.step(LegalActions[np.random.randint(0, len(LegalActions))])

        return reward

    #Here is where you need to return the action that's being taken. Don't feel the need to code ALL of MCTS in this one function. You can break this out into several helper functions. 
    def act(self):

        #Simulate The Environment
        simulated_current_env = UltimateTicTacToeEnv()
        simulated_current_env.set_state(self.env.get_state())

        #Initialize The Root Tree Node at The Current Game State
        MCTSNode.NodeCount = 0
        Root: MCTSNode = MCTSNode(simulated_current_env)

        for Time in range(1, self.iterations + 1):
            '''Selection'''
            #Traverse to a Non-Terminal Leaf Node With Maximum Q Value
            BestLeaf = self.GetBestLeafNode(Root)

            #All Options Have Been Traversed or MaxNodes Has Been Reached
            if BestLeaf is None:
                break

            '''Expansion'''
            #Choose a New Action From All Legal Actions at This Depth
            ExpansionAction: tuple[tuple[int]] = next(iter(set(BestLeaf.env.legal_actions()) - {Child.Action for Child in BestLeaf.Children}))

            #Simulate The Action Into The Expanded Node & Add That Action Into The Tree
            simulated_env: UltimateTicTacToeEnv = UltimateTicTacToeEnv()
            simulated_env.set_state(BestLeaf.env.get_state())
            _, reward, done, _ = simulated_env.step(ExpansionAction)
            ExpansionNode: MCTSNode = MCTSNode(simulated_env, ExpansionAction, BestLeaf)

            '''Simulation'''
            #Get EndGameValue Following a Random Path to The End
            EndGameValue: int = self.RandomGamePath(ExpansionNode, reward, done)

            '''Back Propogate'''
            CurrentNode: MCTSNode = ExpansionNode
            while CurrentNode is not None:
                CurrentNode.UpdateUCB(self.env.game.current_player.value, EndGameValue, Time)
                CurrentNode = CurrentNode.Parent

        #Choose The Best Action at The Root
        BestChildren: list[MCTSNode] = [next(iter(Root.Children))]
        for Child in Root.Children:
            if Child.QValue > BestChildren[0].QValue:
                BestChildren = [Child]
            elif Child.QValue == BestChildren[0].QValue:
                BestChildren.append(Child)

        return BestChildren[np.random.randint(0, len(BestChildren))].Action, None

#I find it useful to define your basic node when implementing a tree, especially one as complicated as the MCTS tree. You do not have to use this, so feel free to delete this and implement it your own way. The only requirement is that the MCTSAgent needs to have an init function and an act function. 
class MCTSNode(MCTSAgent):

    #Max 500 Nodes
    MaxNodes: int = 500
    NodeCount: int = 0

    def __init__(self, Environment: "UltimateTicTacToeEnv", Action: tuple[tuple[int]] = None, Parent: "MCTSNode" = None):

        MCTSNode.NodeCount += 1
        self.Parent: MCTSNode = Parent
        self.Action: tuple[tuple[int]] = Action
        self.VisitCount: int = 0
        self.WinCount: int = 0
        self.QValue: float = 0
        self.Children: set[MCTSNode] = set()
        self.env: UltimateTicTacToeEnv = Environment
        if Parent is not None:
            Parent.Children |= {self}

    def UpdateUCB(self, us: int, EndGameValue: int, Time: int) -> float:

        self.WinCount += 1 if EndGameValue == us else 0
        self.VisitCount += 1
        self.QValue = self.WinCount / self.VisitCount + MCTSNode.exploration_weight * np.sqrt(np.log2(Time) / self.VisitCount)