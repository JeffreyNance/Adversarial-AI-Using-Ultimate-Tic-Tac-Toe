import numpy as np

class RandomAgent:
    Count = 0

    def __init__(self, env):
        self.env = env
        self.Name = f"RandomAgent{'' if RandomAgent.Count < 1 else RandomAgent.Count}"
        RandomAgent.Count += 1

    def act(self):

        LegalActions = self.env.legal_actions()
        return LegalActions[np.random.randint(0, len(LegalActions))], None