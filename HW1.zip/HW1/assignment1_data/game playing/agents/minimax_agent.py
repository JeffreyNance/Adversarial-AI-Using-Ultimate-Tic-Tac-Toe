from utttenv import UltimateTicTacToeEnv
import numpy as np

class MinimaxAgent:
    Count = 0

    def __init__(self, env: UltimateTicTacToeEnv, depth=5):
        self.env = env
        self.depth = depth
        self.Name = f"MinimaxAgent{'' if MinimaxAgent.Count < 1 else MinimaxAgent.Count}"
        MinimaxAgent.Count += 1

    #Here is where you should implement your minimax search method. You are free to do this however you like, it the act function just needs to return the action that is to be taken. 
    def act(self, depth: int = 0, simulated_current_env = None) -> tuple[tuple[int, int], tuple[int, int]] | int:
        '''
        Always Start Depth at 0\n
        Never Input simulated_current_env
        '''

        #Initializations
        if not(depth):
            simulated_current_env = UltimateTicTacToeEnv()
            simulated_current_env.set_state(self.env.get_state())

        #Get All Legal Actions at This Depth
        LegalActions = simulated_current_env.legal_actions()

        #Search For The Best Current Action Based on The Next Five Moves (Including This Move)
        DepthMinus: bool = depth == self.depth - 1
        CurrDepthPlus: int = depth + 1
        BestLocation: int = 0
        ActionValue: int = 0
        MinNode: int = depth % 2
        BestValue: int = 99999 if MinNode else -99999 #Greater/Less Than Any Real Value
        for location, action in enumerate(LegalActions):
            #Simulate The Action
            simulated_env = UltimateTicTacToeEnv()
            simulated_env.set_state(simulated_current_env.get_state())
            _, _, done, _ = simulated_env.step(action)

            #Get The Value of This Action
            if DepthMinus or done:
                #Evaluate The Deepest Layer of Search
                ActionValue = self.evaluate(simulated_env)
            else:
                #Take The MiniMax of The Layer Below
                _, ActionValue = self.act(CurrDepthPlus, simulated_env)

            #Determine if This Action Path is The Best Action Path For The Agent
            if (MinNode and ActionValue < BestValue) or (not(MinNode) and ActionValue > BestValue) or (np.random.random() < 0.3 and ActionValue == BestValue):
                BestValue = ActionValue
                BestLocation = location

        #Return Best Action & The Associated Value
        return LegalActions[BestLocation], BestValue

    #Use this function to evaluate functions. This can be used to evaluate terminal states as well as non-terminal states. It's a relatively simple heuristic, but should get the job done. 
    #Had to Differentiate The Current Simulated Player From The Actual Current Player (Also Fixed Turn Order Issue) -> Same Function, Just Inverted For The Opposite Player
    #I am Unsure if my Fix Was a Fix From my Own Earlier Change or From Your Original Function
    def evaluate(self, env: UltimateTicTacToeEnv) -> int:
        winner = env.game.evaluate_global_win()
        usvalue = self.env.game.current_player.value
        us = 1 if env.game.current_player.value == usvalue else -1
        score: int = winner * 100 * us if winner != 2 else 0

        for row in env.game.local_board_states:
            for state in row:
                if state.value == usvalue:
                    score += 10 if us == 1 else 50
                elif state.value == -usvalue:
                    score += -50 if us == 1 else -10

        return score