from enum import Enum
from itertools import batched, chain
from typing import Final


class SpaceOccupancy(Enum):
    EMPTY = 0
    PLAYER_ONE = 1
    PLAYER_TWO = -1

    def text_repr(self) -> str:
        match self:
            case SpaceOccupancy.EMPTY:
                return ' '
            case SpaceOccupancy.PLAYER_ONE:
                return 'X'
            case SpaceOccupancy.PLAYER_TWO:
                return 'O'


class LocalBoardState(Enum):
    UNDECIDED = 0
    PLAYER_ONE_WIN = 1
    PLAYER_TWO_WIN = -1
    TIE = 2

    def text_repr(self) -> str:
        match self:
            case LocalBoardState.UNDECIDED:
                return ' '
            case LocalBoardState.PLAYER_ONE_WIN:
                return 'X'
            case LocalBoardState.PLAYER_TWO_WIN:
                return 'O'
            case LocalBoardState.TIE:
                return 'C'


class Player(Enum):
    PLAYER_ONE = 1
    PLAYER_TWO = -1


class PlayableConstraint(Enum):
    UNAVAILABLE = 0
    AVAILABLE = 1


BOARD_DIMENSION: Final = 3


class UltimateTicTacToe:
    def __init__(self) -> None:
        self.global_board: list[list[list[list[SpaceOccupancy]]]] = [
            [
                [
                    [SpaceOccupancy.EMPTY] * BOARD_DIMENSION
                    for _ in range(BOARD_DIMENSION)
                ]
                for _ in range(BOARD_DIMENSION)
            ]
            for _ in range(BOARD_DIMENSION)
        ]

        self.local_board_states: list[list[LocalBoardState]] = [
            [LocalBoardState.UNDECIDED] * BOARD_DIMENSION
            for _ in range(BOARD_DIMENSION)
        ]

        self.next_board_mask: list[list[PlayableConstraint]] = [
            [PlayableConstraint.AVAILABLE] * BOARD_DIMENSION
            for _ in range(BOARD_DIMENSION)
        ]

        self.current_player: Player = Player.PLAYER_ONE

    def make_move(
        self,
        global_board_position: tuple[int, int],
        local_board_move: tuple[int, int],
    ) -> int:
        global_row, global_column = global_board_position

        if global_row not in range(BOARD_DIMENSION):
            raise ValueError(f'Invalid row for global board: {global_row}')
        if global_column not in range(BOARD_DIMENSION):
            raise ValueError(f'Invalid column for global board: {global_column}')

        if (
            self.next_board_mask[global_row][global_column]
            is PlayableConstraint.UNAVAILABLE
        ):
            raise ValueError(
                f'Selected an invalid board to move on: {global_board_position!s}'
            )

        local_board = self.global_board[global_row][global_column]
        local_row, local_column = local_board_move

        if local_row not in range(BOARD_DIMENSION):
            raise ValueError(f'Invalid row for local board: {local_row}')
        if local_column not in range(BOARD_DIMENSION):
            raise ValueError(f'Invalid column for local board: {local_column}')

        if local_board[local_row][local_column] is not SpaceOccupancy.EMPTY:
            raise ValueError(
                f'Attempted space to move was already occupied: {local_board_move!s}'
            )

        local_board[local_row][local_column] = SpaceOccupancy(self.current_player.value)

        self.switch_player()
        self.evaluate_local_win(global_board_position)
        self.update_board_mask(local_board_move)
        return self.evaluate_global_win()

    def switch_player(self):
        self.current_player = Player.PLAYER_TWO if self.current_player is Player.PLAYER_ONE else Player.PLAYER_ONE

    def update_board_mask(self, local_board_move: tuple[int, int]) -> None:
        local_row, local_column = local_board_move
        local_state = self.local_board_states[local_row][local_column]
        self.next_board_mask = [
            [PlayableConstraint.UNAVAILABLE if local_state is LocalBoardState.UNDECIDED else PlayableConstraint.AVAILABLE] * BOARD_DIMENSION
            for _ in range(BOARD_DIMENSION)
        ]
        if local_state is LocalBoardState.UNDECIDED:
            self.next_board_mask[local_row][local_column] = PlayableConstraint.AVAILABLE
        else:
            for row_index, row in enumerate(self.local_board_states):
                for column_index, state in enumerate(row):
                    if state is not LocalBoardState.UNDECIDED:
                        self.next_board_mask[row_index][column_index] = PlayableConstraint.UNAVAILABLE

    def evaluate_local_win(self, global_board_position: tuple[int, int]) -> None:
        global_row, global_column = global_board_position
        local_board = self.global_board[global_row][global_column]

        winner = self._check_board([[space.value for space in row] for row in local_board])
        if winner:
            self.local_board_states[global_row][global_column] = LocalBoardState(winner)

    def evaluate_global_win(self) -> int:
        return self._check_board([[space.value for space in row] for row in self.local_board_states])

    @staticmethod
    def _check_board(board: list[list[int]]) -> int:
        flattened_board = tuple(chain(*board))
        ways_to_win = (
            (0, 1, 2),
            (3, 4, 5),
            (6, 7, 8),
            (0, 3, 6),
            (1, 4, 7),
            (2, 5, 8),
            (0, 4, 8),
            (2, 4, 6),
        )

        for position1, position2, position3 in ways_to_win:
            if flattened_board[position1] and (flattened_board[position1] == flattened_board[position2] == flattened_board[position3]):
                return flattened_board[position1]

        if all(space != 0 for space in flattened_board):
            return 2

        return 0

    def print_board(self) -> None:
        for outer_row in range(BOARD_DIMENSION):
            for inner_row in range(BOARD_DIMENSION):
                line = []
                for outer_col in range(BOARD_DIMENSION):
                    line.extend(self.global_board[outer_row][outer_col][inner_row])

                print('|'.join(map(' '.join,
                    batched(map(lambda space: space.text_repr(), line), BOARD_DIMENSION)
                )))
            if outer_row != BOARD_DIMENSION - 1:
                print('+'.join(['-' * (BOARD_DIMENSION * 2 - 1)] * BOARD_DIMENSION))

    def print_claimed_boards(self) -> None:
        for i, row in enumerate(self.local_board_states):
            print('|'.join(map(lambda s: s.text_repr(), row)))

            if i != BOARD_DIMENSION - 1:
                print('-+-+-')

    def get_state(self):
        return {
            'global_board': [
                [[[space.value for space in row] for row in board] for board in row]
                for row in self.global_board
            ],
            'local_board_states': [
                [state.value for state in row] for row in self.local_board_states
            ],
            'next_board_mask': [
                [constraint.value for constraint in row] for row in self.next_board_mask
            ],
            'current_player': self.current_player.value,
        }

    def set_state(self, state):
        self.global_board = [
            [[[SpaceOccupancy(cell) for cell in row] for row in board] for board in row]
            for row in state['global_board']
        ]
        self.local_board_states = [
            [LocalBoardState(status) for status in row]
            for row in state['local_board_states']
        ]
        self.next_board_mask = [
            [PlayableConstraint(mask) for mask in row]
            for row in state['next_board_mask']
        ]
        self.current_player = Player(state['current_player'])
