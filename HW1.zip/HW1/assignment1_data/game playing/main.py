from agents.heuristic_agent import HeuristicAgent
from agents.random_agent import RandomAgent
from agents.minimax_agent import MinimaxAgent
from agents.alpha_beta_agent import AlphaBetaAgent
from agents.mcts_agent import MCTSAgent
from utttenv import UltimateTicTacToeEnv
import matplotlib.pyplot as plt

uttt_env = UltimateTicTacToeEnv()
Agents = (RandomAgent, HeuristicAgent, MinimaxAgent, AlphaBetaAgent, MCTSAgent)

def play_games(env, agent1, agent2, num_games):
    results = {'agent1 wins': 0, 'agent2 wins': 0, 'ties': 0}

    for _ in range(num_games):
        env.reset()
        done = False
        current_agent = agent1

        while not done:
            action, _ = current_agent.act()
            _, _, done, info = env.step(action)
            #env.render()
            current_agent = agent2 if current_agent == agent1 else agent1

        if info['winner'] == 1:
            results['agent1 wins'] += 1
        elif info['winner'] == -1:
            results['agent2 wins'] += 1
        else:
            results['ties'] += 1
    return results

def CompareAllAgents():
    TotalGames: int = 6

    #Run These Agents Against Each Other TotalGames Times
    for Agent1 in Agents:
        for Agent2 in Agents:
            RunChosenGame(Agent1(uttt_env), Agent2(uttt_env), TotalGames)
            Agent1.Count = 0
            Agent2.Count = 0

def PrintResults(Agent1, Agent2, TotalGames, results):

    #Display Results
    plt.bar((Agent1.Name, Agent2.Name, "Ties"), results.values(), color = "b", label = f"Player 1: {Agent1.Name}\nPlayer 2: {Agent2.Name}")
    plt.title(f"Agent Wins Over {TotalGames} Games Given Turn Order")
    plt.xlabel("Agents")
    plt.ylabel("Number of Wins")
    plt.legend()
    plt.tight_layout()
    plt.show()

def RunChosenGame(Agent1, Agent2, TotalGames: int) -> None:

    #Run These Agents Against Each Other TotalGames Times
    results = play_games(uttt_env, Agent1, Agent2, TotalGames)

    #Print The Number of Prunings
    if isinstance(Agent1, AlphaBetaAgent):
        print(f"{Agent1.Name} Pruned {Agent1.NumberPrunes} Times Total as Player 1 Against {Agent2.Name}.")
    if isinstance(Agent2, AlphaBetaAgent):
        print(f"{Agent2.Name} Pruned {Agent2.NumberPrunes} Times Total as Player 2 Against {Agent1.Name}.")

    #Print The Results
    PrintResults(Agent1, Agent2, TotalGames, results)

if __name__ == "__main__":
    CompareAllAgents()