from uttt import PlayableConstraint, SpaceOccupancy, UltimateTicTacToe

class UltimateTicTacToeEnv:
    def __init__(self):
        self.game = UltimateTicTacToe()
        self.state = None

    def reset(self):
        self.game = UltimateTicTacToe()
        self.state = self.get_state()
        return self.state

    def step(self, action: tuple[tuple[int, int], tuple[int, int]]):
        try:
            global_position, local_position = action
            winner = self.game.make_move(global_position, local_position)

            reward = winner if winner != 2 else 0
            self.state = self.get_state()
            done = bool(winner)
            info = {'winner': winner}

            return self.state, reward, done, info
        except ValueError as e:
            raise ValueError(f'Invalid move: {e}')

    def render(self):
        import sys

        sys.stdout.write('\033[2J\033[H')
        sys.stdout.flush()
        self.game.print_board()
        print()
        self.game.print_claimed_boards()

    def legal_actions(self) -> list[tuple[tuple[int, int], tuple[int, int]]]:
        legal_actions = []
        for i in range(3):
            for j in range(3):
                if self.game.next_board_mask[i][j] == PlayableConstraint.AVAILABLE:
                    for k in range(3):
                        for l in range(3):
                            if self.game.global_board[i][j][k][l] == SpaceOccupancy.EMPTY:
                                legal_actions.append(((i, j), (k, l)))

        return legal_actions

    def get_state(self):
        return self.game.get_state()

    def set_state(self, state):
        self.game.set_state(state)
