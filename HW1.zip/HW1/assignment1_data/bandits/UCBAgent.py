import numpy as np

class UCBAgent:
    def __init__(self):
        self.name = "Uma the UCB Agent"

    def recommendArm(self, bandit, time: int):

        #This Automatically Makes Exploration More Appealing Over Time, Balancing Exploitation
        Recommend: int = 0
        for Arm in range(len(bandit.arms)):
            #Use a Dictionary to Store UCB Appeal of Searched Arms
            #The Second Half is The Upper Confidence Bound of Pulling This Arm
            #Prevent Division by Zero by Starting Visited at 1
            bandit.AppealUCB[Arm] = bandit.ExpectedRewards[Arm] + np.sqrt(2 * np.log2(time) / bandit.Visited[Arm])

            if bandit.AppealUCB[Arm] > bandit.AppealUCB[Recommend]:
                Recommend = Arm

        return Recommend
