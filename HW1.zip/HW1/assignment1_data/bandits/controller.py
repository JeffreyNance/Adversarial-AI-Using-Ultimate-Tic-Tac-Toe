import numpy as np
from randAgent import randomAgent
from epsGreedyAgent import epsGreedyAgent
from UCBAgent import UCBAgent
from thompsonAgent import thompsonAgent
import matplotlib.pyplot as plt
import argparse
######################################################
AGENTS_MAP = {'randomAgent' : randomAgent,
               'epsGreedyAgent' : epsGreedyAgent,
              'UCBAgent': UCBAgent,
              'thompsonAgent': thompsonAgent  }

class bandit: 
    def __init__(self, file):
        lines = open(file, "r").readlines()
        self.arms: list[float] = [float(lines[i].rstrip("\n")) for i in range(1, len(lines))]
        self.MaxReward: float = max(self.arms)

        #Used For Describing The Effectiveness of an Agent
        self.TotalRegret: list[float] = [0]

        #Used For Estimating Quality of an Action
        #Start Visited at Once Because UCB & Thompson Needs Not to Divide by 0. Does Not Significantly Affect Results
        self.Visited: dict[int, int] = {arm: 1 for arm in range(len(self.arms))}
        self.TotalRewards: dict[int, int] = {arm: 0 for arm in range(len(self.arms))}
        self.ExpectedRewards: dict[int, float] = {arm: 0 for arm in range(len(self.arms))}

        #Upper Confidence Bound For UCBAgent
        self.AppealUCB: dict[int, float] = {arm: 0 for arm in range(len(self.arms))}

        #AlphaBeta For Thompson Agent -> Starts as [1, 1]
        self.AlphaBeta: dict[int, np.ndarray[np.int32]] = {arm: np.array([1, 1], np.int32) for arm in range(len(self.arms))}
        self.FakeAverageReward: dict[int, int] = {arm: 0 for arm in range(len(self.arms))}

    def pull_arm(self, arm: int):
        '''Returns Either 0 or 1'''

        #Reward is in [0, 1]
        Reward: int = int(np.random.random() <= self.arms[arm])

        #Update Expected Reward For The Given Arm
        self.Visited[arm] += 1
        self.TotalRewards[arm] += Reward
        self.ExpectedRewards[arm] = self.TotalRewards[arm] / self.Visited[arm]
        self.TotalRegret.append(self.TotalRegret[-1] + (self.MaxReward - self.arms[arm]))

        #Update Alpha & Beta For The Given Arm
        self.AlphaBeta[arm][1 - Reward] += 1

        return Reward


def Test_Agent(GivenAgent: str, TotalPulls: int, Test: str) -> int:
    parser = argparse.ArgumentParser(description='Define bandit problem and agents.')
    parser.add_argument('--input', choices=['input/test0.txt', 'input/test1.txt'], default=Test, help='The input file, can be input/test0.txt or input/test1.txt')
    parser.add_argument('--agent', choices=AGENTS_MAP.keys(), default=GivenAgent, help='The bandit AI. Can be randomAgent, epsGreedyAgent, UCBAgent, or thompsonAgent')
    parser.add_argument('--num_plays', type=int, default = TotalPulls, help='The number of pulls an agent has.')
    args = parser.parse_args()

    testBandit = bandit(args.input)
    agent = AGENTS_MAP[args.agent]()
    cumulative_reward = 0
    for time in range(1, args.num_plays + 1):
        testArm = agent.recommendArm(testBandit, time)
        reward = testBandit.pull_arm(testArm)
        cumulative_reward += reward

    return cumulative_reward, testBandit.TotalRegret

def RunAllAgents(TotalPulls: int) -> None:

    #Run All Tests With The Same Number of Pulls For Each Agent
    Regret: list[float] = []
    Reward: int = 0
    Colors: tuple[str] = ("r", "g", "b", "y")
    for Test in ("input/test0.txt", "input/test1.txt"):
        print(f"\n{Test} w/{TotalPulls} Pulls:")
        AgentNames: list[str] = tuple(AGENTS_MAP.keys())
        for i, GivenAgent in enumerate(AgentNames):
            Reward, Regret = Test_Agent(GivenAgent, TotalPulls, Test)
            print(f"\t{GivenAgent}'s Reward: {Reward}")
            #Plot The Regret of All Agents
            plt.plot(Regret, color = Colors[i], label = AgentNames[i])

        #Show The Plot of The Regret of All Agents
        plt.xlabel("Number of Pulls")
        plt.ylabel("Total Regret")
        plt.title(f"Multi-Agent Regret Growth For Multi-Armed Bandits: {Test}")
        plt.legend()
        plt.show()

RunAllAgents(10000)