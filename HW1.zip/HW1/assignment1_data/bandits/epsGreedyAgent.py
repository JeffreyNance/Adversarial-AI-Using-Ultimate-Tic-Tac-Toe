
import numpy as np
######################################################

class epsGreedyAgent: 
    def __init__(self):
        self.name = "Eric the Epsilon Greedy Agent"
        self.epsilon = 0.9
    
    def recommendArm(self, bandit, _) -> int:

        #Choose a Random Arm
        Recommend: int = 0
        if np.random.random() <= self.epsilon:
            Recommend = np.random.randint(0, len(bandit.arms))

        #Choose The Best Available Arm
        else:
            for Arm in range(len(bandit.arms)):
                if bandit.ExpectedRewards[Arm] > bandit.ExpectedRewards[Recommend]:
                    Recommend = Arm

        #Decay Epsilon to 0.1
        if self.epsilon > 0.1:
            self.epsilon -= 0.05

        return Recommend
