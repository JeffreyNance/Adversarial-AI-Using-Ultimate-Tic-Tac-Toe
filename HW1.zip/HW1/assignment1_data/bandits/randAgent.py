import numpy as np

class randomAgent: 
	def __init__(self):
		self.name = "Randy the RandomAgent"

	def recommendArm(self, bandit, _) -> int:
		return np.random.randint(0, len(bandit.arms))
