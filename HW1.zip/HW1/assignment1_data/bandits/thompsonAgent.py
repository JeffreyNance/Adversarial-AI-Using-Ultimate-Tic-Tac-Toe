import numpy as np
from random import choices

class thompsonAgent: 
    def __init__(self):
        self.name = "Terry the Thompson Sampling Agent" #I Love These Names

    def recommendArm(self, bandit, _):

        Recommend: int = 0
        for Arm in range(len(bandit.arms)):
            #Sample Rewards k Times From Each Arm's Known Distribution
            bandit.FakeAverageReward[Arm] = np.sum(choices((1, 0), bandit.AlphaBeta[Arm] / bandit.Visited[Arm], k = 5))

            #Choose Arm With Best Fake Average Reward
            if bandit.FakeAverageReward[Arm] > bandit.FakeAverageReward[Recommend]:
                Recommend = Arm

        return Recommend
