import math
import random

from utttenv import UltimateTicTacToeEnv


#I find it useful to define your basic node when implementing a tree, especially one as complicated as the MCTS tree. You do not have to use this, so feel free to delete this and implement it your own way. The only requirement is that the MCTSAgent needs to have an init function and an act function. 
class MCTSNode:


class MCTSAgent:
    #Basic init function. I've given you a little bit of a start, but feel free to alter this as you see fit. 
    def __init__(self, env, iterations=500, exploration_weight=0.10):
        self.env = env
        self.iterations = iterations
        self.exploration_weight = exploration_weight

    #Here is where you need to return the action that's being taken. Don't feel the need to code ALL of MCTS in this one function. You can break this out into several helper functions. 
    def act(self):
        
