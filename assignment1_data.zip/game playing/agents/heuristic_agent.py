import random

from utttenv import UltimateTicTacToeEnv


class HeuristicAgent:
    def __init__(self, env: UltimateTicTacToeEnv):
        self.env = env

    def act(self):
        us = self.env.game.current_player.value
        for action in self.env.legal_actions():
            simulated_env = UltimateTicTacToeEnv()
            simulated_env.set_state(self.env.get_state())
            _, _, done, info = simulated_env.step(action)
            if done:
                if info['winner'] == us:
                    return action
            else:
                next_player_board_state = self.env.game.local_board_states[
                    action[1][0]
                ][action[1][1]]
                if next_player_board_state.value != 0:
                    continue

                local_board_state = self.env.game.local_board_states[action[0][0]][
                    action[0][1]
                ]
                if local_board_state.value == us:
                    return action

        return random.choice(self.env.legal_actions())
