import random


class RandomAgent:
    def __init__(self, env):
        self.env = env

    def act(self):
        return random.choice(self.env.legal_actions())
