from utttenv import UltimateTicTacToeEnv


class MinimaxAgent:
    def __init__(self, env: UltimateTicTacToeEnv, depth=5):
        self.env = env
        self.depth = depth

    #Here is where you should implement your minimax search method. You are free to do this however you like, it the act function just needs to return the action that is to be taken. 
    def act(self):
        #Needs to be implemented!
        
    #Use this function to evaluate functions. This can be used to evaluate terminal states as well as non-terminal states. It's a relatively simple heuristic, but should get the job done. 
    def evaluate(self, env: UltimateTicTacToeEnv, us):
        winner = env.game.evaluate_global_win()
        score = 0
        if winner == 1:
            score += 100 * us
        if winner == -1:
            score += -100 * us

        for row in env.game.local_board_states:
            for state in row:
                if state.value == us:
                    score += 10
                elif state.value == -us:
                    score -= 50

        return 0
