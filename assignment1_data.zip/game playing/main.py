from agents.heuristic_agent import HeuristicAgent
from agents.random_agent import RandomAgent
from utttenv import UltimateTicTacToeEnv

uttt_env = UltimateTicTacToeEnv()


def play_games(env, agent1, agent2, num_games):
    results = {'agent1 wins': 0, 'agent2 wins': 0, 'ties': 0}

    for _ in range(num_games):
        env.reset()
        done = False
        current_agent = agent1

        while not done:
            action = current_agent.act()
            _, _, done, info = env.step(action)
            env.render()
            current_agent = agent2 if current_agent == agent1 else agent1

        if info['winner'] == 1:
            results['agent1 wins'] += 1
        elif info['winner'] == -1:
            results['agent2 wins'] += 1
        else:
            results['ties'] += 1
    return results


if __name__ == '__main__':
    print(play_games(uttt_env, RandomAgent(uttt_env), RandomAgent(uttt_env), 5))